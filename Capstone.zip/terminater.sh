sudo kill -9 $(pidof python3)
